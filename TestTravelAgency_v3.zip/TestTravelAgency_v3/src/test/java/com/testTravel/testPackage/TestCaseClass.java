/**
 * This is to enter the test data
 */

package com.testTravel.testPackage;
 

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.SkipException;

import org.testng.annotations.*;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.testTravel.frameworkPackage.BrowserFactory;
import com.testTravel.frameworkPackage.CaptureScreenShot;
import com.testTravel.uiPackage.BookFlightPage;
import com.testTravel.uiPackage.FlightConfirmationPage;
import com.testTravel.uiPackage.FlightFinderPage;
import dataTestTravelProvider.ConfigFileReader;
import com.testTravel.uiPackage.SelectFlightPage;
import Util.TestUtil;

	public class TestCaseClass{
 

public static  WebDriver driver;
ConfigFileReader configFileReader=new ConfigFileReader();;

 BrowserFactory obj1;
 String browser=configFileReader.getBrowserType();

@BeforeMethod
public void checkBrowser(){
	
	System.out.println("Initiating " +browser+" browser now......");
	obj1=PageFactory.initElements(driver, BrowserFactory.class);
	TestCaseClass.driver = BrowserFactory.getDriver(browser);	
}

@DataProvider
public Object[][] getTestData()
{
	Object data[][]=TestUtil.getTestData("passengerdetails"); // calling Excel for passenger details sheet for test data.
	
	return data;
}




 @AfterSuite
public void afterSuite() throws IOException{
 
driver.quit();
}
 
 
//testcase scenerio to validate if the ticket is booked and screenshot captured
@Test(dataProvider = "getTestData")
public void flightTicket(String Source,String Destination,String FlightNo,
		String Name,String Address,String City,String State,
		String	Pincode,String	Cardtype,String	CardNumber,String ExpiryMonth,String ExpiryYear,String	Cardname,String	Remember) {
	
		driver.get(configFileReader.getApplicationUrl());
		System.out.println("check flight availability");

try {
	
//Flight finder
FlightFinderPage flightFinderpage = PageFactory.initElements(driver, FlightFinderPage.class);
flightFinderpage.checkFlight(Source,Destination);

//Select flight
SelectFlightPage selectFlightPage = PageFactory.initElements(driver, SelectFlightPage.class);
selectFlightPage.AirlineSelect(FlightNo);

//Book flight and details
BookFlightPage bookFlightPage = PageFactory.initElements(driver, BookFlightPage.class);
bookFlightPage.passengerDetails(Name,Address,City,State,Pincode,Cardtype,CardNumber,ExpiryMonth,ExpiryYear,Cardname,Remember);

//No validations for these filed's 


bookFlightPage.puchase();

//Flight confirmation
FlightConfirmationPage flightConfirmationPage = PageFactory.initElements(driver, FlightConfirmationPage.class);

//Verify the booking confirmation ID
flightConfirmationPage.confirmID();


//Capture Screenshot
String screenshotLocation ="test-output/ScreenShots/"+"ConfirmTicket_"+CaptureScreenShot.getDateTimeStamp()+".png";
try {
	CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(browser), screenshotLocation);
} catch (Exception e) {
	e.printStackTrace();
	}

} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}



//testcase scenerio to validate the remember check icon and fill data and screenshot captured
@Test(dataProvider = "getTestData")
public void rememberPassengerDetails(String Source,String Destination,String FlightNo,
		String Name,String	Address,String	 City,String	State,
		String	Pincode,String	Cardtype,String	CardNumber,String	ExpiryMonth,String	 ExpiryYear,String	Cardname,String	Remember) {
	
	System.out.println("check passenger details if Remember is enabled");
	driver.get(configFileReader.getApplicationUrl());
	
	
	//Flight finder
	FlightFinderPage flightFinderpage = PageFactory.initElements(driver, FlightFinderPage.class);
	flightFinderpage.checkFlight(Source,Destination);
	SelectFlightPage selectFlightPage = PageFactory.initElements(driver, SelectFlightPage.class);
	selectFlightPage.AirlineSelect(FlightNo);
	//Book flight if remembered data
	try {		
		BookFlightPage bookFlightPage = PageFactory.initElements(driver, BookFlightPage.class);
		if(Remember.contentEquals("1"))
		{
		//bookFlightPage.rememberEnable(Remember);
		bookFlightPage.passengerDetails(Name,Address,City,State,Pincode,Cardtype,CardNumber,ExpiryMonth,ExpiryYear,Cardname,Remember);
		System.out.println("data auto filled ");
		}
		else {
			System.out.println("data not auto filled.");
		}
		//Capture Screenshot
		String screenshotLocation ="test-output/ScreenShots/"+"Remembercheck"+CaptureScreenShot.getDateTimeStamp()+".png";
		try {
			CaptureScreenShot.getScreenShot(BrowserFactory.getDriver(browser), screenshotLocation);
		} catch (Exception e) {
			e.printStackTrace();
		}		 		
	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}

}
}

	

 

