/**
 * To check the browser  Chrome or firefox 
 */

package com.testTravel.frameworkPackage;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxOptions;
import dataTestTravelProvider.ConfigFileReader;

public class BrowserFactory {
 
public static WebDriver driver;
 
public BrowserFactory(){
 
}
 static ConfigFileReader configFileReader;


 
public static WebDriver getDriver(String browserName){
if(driver==null){
	if(browserName.equalsIgnoreCase("chrome")){
	
		configFileReader= new ConfigFileReader();
		System.setProperty("webdriver.chrome.driver", configFileReader.getDriverPath());
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();


		}
else
if(browserName.equalsIgnoreCase("firefox")){
			
			 configFileReader= new ConfigFileReader();
		     System.setProperty("webdriver.gecko.driver", configFileReader.getDriverPath());
		     driver=new FirefoxDriver();
		     driver.manage().window().maximize();
		     driver.manage().deleteAllCookies();

}
}
return driver;
}
}