/**
 * This page is used to select the flight
 */

package com.testTravel.uiPackage;
 
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

 
public class SelectFlightPage {
 
WebDriver driver;
 
public SelectFlightPage(WebDriver driver){
this.driver=driver;
}


/* To choose corresponding  flight the user selects and submit*/
public void AirlineSelect( String fno){
try {
		
	WebElement tb = driver.findElement(By.className("table"));
	List<WebElement> rows = tb.findElements(By.tagName("td"));
	int i,j;
	for(i=1,j=1;i<rows.size(); ){
		if(fno.contentEquals(rows.get(i).getText()))
		{
			System.out.println("Selected flight number from page : "+rows.get(i).getText());
			driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr["+j+"]/td[1]/input")).click();			
			break;
		}
		else 
		{
			i=i+6;
			j=j+1;
		}		
	}
			
Thread.sleep(2000);
}
 catch (InterruptedException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
 
}
 

 
}