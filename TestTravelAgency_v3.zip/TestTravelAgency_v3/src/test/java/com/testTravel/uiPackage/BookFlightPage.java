/**
 * This is to book the flight providing the details
 */
/**
 * @author deepukiran
 *
 */
package com.testTravel.uiPackage; 


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

 
public class BookFlightPage {
 
WebDriver driver;
 
public BookFlightPage(WebDriver driver){
this.driver=driver;
}
 
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[1]/div/input")
@CacheLookup
WebElement name;
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[2]/div/input")
@CacheLookup
WebElement address;
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[3]/div/input")
@CacheLookup
WebElement city;
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[4]/div/input")
@CacheLookup
WebElement state;
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[5]/div/input")
@CacheLookup
WebElement code;
@FindBy(how=How.ID ,using="cardType")
@CacheLookup
WebElement cardt;
@FindBy(how=How.NAME,using="creditCardNumber")
@CacheLookup
WebElement ccnumber;
@FindBy(how=How.NAME,using="creditCardMonth")
@CacheLookup
WebElement month;
@FindBy(how=How.NAME,using="creditCardYear")
@CacheLookup
WebElement year;
@FindBy(how=How.NAME,using="nameOnCard")
@CacheLookup
WebElement cardName;
@FindBy(how=How.ID,using="rememberMe")
@CacheLookup
WebElement e;
@FindBy(how=How.XPATH,using="/html/body/div[2]/form/div[11]/div/input")
@CacheLookup
WebElement purchase;


public void passengerDetails(String nam,String add,String cit,String stat,String cod,String ctype,String cnum,String mon,String yr,String cnam,String enable){
	try {
		Thread.sleep(500);
		name.sendKeys(nam);
		Thread.sleep(100);
		address.sendKeys(add);
		Thread.sleep(100);
		city.sendKeys(cit);
		Thread.sleep(100);
		state.sendKeys(stat);
		Thread.sleep(100);
		code.sendKeys(cod);
		Thread.sleep(100);
		cardt.sendKeys(ctype );
		Thread.sleep(100);
		ccnumber.sendKeys(cnum);
		Thread.sleep(100);
		month.clear();
		month.sendKeys(mon);
		Thread.sleep(100);
		year.clear();
		year.sendKeys(yr);
		Thread.sleep(100);
		cardName.sendKeys(cnam);
		Thread.sleep(100);
		rememberEnable(enable);
		Thread.sleep(100);
		
	}catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}
	

public void puchase()
{
	purchase.click();	
}

public void rememberEnable(String enab)
{
	if (enab.isEmpty()	)
	{
		System.out.println("remember me disabled");
		//e.clear(); 	    
	}
	else
	{
		System.out.println("remember me enabled");
	    e.click();
		}
	}

}
