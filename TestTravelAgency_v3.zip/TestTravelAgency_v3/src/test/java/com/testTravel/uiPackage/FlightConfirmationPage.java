/**
 * This is the confirmation page for the booked flight
 */
/**
 * @author deepukiran
 *
 */
package com.testTravel.uiPackage; 
 
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FlightConfirmationPage {
 
	WebDriver driver;
 
public FlightConfirmationPage(WebDriver driver){
this.driver=driver;
}
 
public void confirmID() throws InterruptedException
{	
	/* get all details from confirmation page*/

	WebElement tb = driver.findElement(By.className("table"));
	List<WebElement> rows = tb.findElements(By.tagName("td"));

	String confirmID=rows.get(1).getText();
	

	/*verify Id is null*/
	
	if(confirmID.isEmpty())
	{
		System.out.println("ID is empty");
	    return;
    }
    else
	     System.out.println("ID is "+confirmID);	
	
//	return confirmID;
}	


public void checkStatus(String Status)  
{	
	/* check the status of the flight confirmed*/
	
}


}
