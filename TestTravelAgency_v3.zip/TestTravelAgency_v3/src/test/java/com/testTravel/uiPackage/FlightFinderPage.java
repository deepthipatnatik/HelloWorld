/**
 * This is the first page to find the flights between two places
 */
/**
 * @author deepukiran
 *
 */
package com.testTravel.uiPackage;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
 
public class FlightFinderPage {
 
WebDriver driver;
 
public FlightFinderPage(WebDriver driver){
this.driver=driver;
}

@FindBy(how=How.NAME,using="fromPort")
@CacheLookup
WebElement airlinefrom;
@FindBy(how=How.NAME,using="toPort")
@CacheLookup
WebElement airlineto;
@FindBy(how=How.XPATH,using="/html/body/div[3]/form/div/input")
@CacheLookup
WebElement findFlights;
 

 
public void checkFlight(String alinefrom,String alineto) {
try {
	System.out.println("Checking flight"+alinefrom+" "+alineto);
    airlinefrom.sendKeys(alinefrom);
    Thread.sleep(2000);
    airlineto.sendKeys(alineto);
    Thread.sleep(2000);
    findFlights.submit();
    Thread.sleep(2000);
	} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
}
}