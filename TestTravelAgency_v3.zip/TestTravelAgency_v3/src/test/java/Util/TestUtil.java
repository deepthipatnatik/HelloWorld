
/* PAckage to read data from excel file*/

package Util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
public class TestUtil {
	
	static Workbook book;
	static Sheet sheet;
	public static String Test_Data_Sheet_Path="/Users/deepukiran/eclipse-workspace/TestTravelAgency/"
			+ "src/test/java/testTravelData/TestTravelData.xlsx";
	
	public static Object[][] getTestData(String sheetname) 
	{
		FileInputStream file=null;
		try {
			file=new FileInputStream(Test_Data_Sheet_Path);			
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
		try {
			book=WorkbookFactory.create(file);			
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		sheet=book.getSheet(sheetname);
		int lastrownum=sheet.getLastRowNum();
		int lastcolnum=sheet.getRow(0).getLastCellNum();		
		Object[][] data=new Object[lastrownum][lastcolnum];						
		for(int i=0; i<lastrownum;i++)
		{		
			for (int k=0;k < lastcolnum;k++)
			{	
				if(sheet.getRow(i+1).getCell(k).getStringCellValue()!="")
				{					
					data[i][k]=sheet.getRow(i+1).getCell(k).toString();
					System.out.print(data[i][k]+" ");										
					}					
			}							
			System.out.println("\n");
		}				
		return data;
	}	
}
